module knowingNumber {
	exports application;

	requires javafx.base;
	requires javafx.graphics;
	requires javafx.controls;
	requires java.logging;
}