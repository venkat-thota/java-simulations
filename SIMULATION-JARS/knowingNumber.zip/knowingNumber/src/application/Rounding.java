package application;

import java.net.URISyntaxException;
import java.net.URL;
import java.util.ArrayList;

import javafx.animation.Animation;
import javafx.animation.AnimationTimer;
import javafx.animation.FadeTransition;
import javafx.animation.RotateTransition;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Point2D;
import javafx.geometry.Pos;
import javafx.geometry.VPos;
import javafx.scene.Cursor;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.ClipboardContent;
import javafx.scene.input.DragEvent;
import javafx.scene.input.Dragboard;
import javafx.scene.input.MouseEvent;
import javafx.scene.input.TransferMode;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.Border;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.stage.Screen;
import javafx.stage.Stage;
import javafx.util.Duration;

public class Rounding extends Application {
	
    ImageView iv;
    int nombreLeft = 10; 
    int nombreRight = 0; 
    int curseur = 0 ;
    double initX = 0;
    StackPane root;
    Text text1;
    Text text2;
    int holeWidth = 96;
    Button roundOff = new Button("ROUND");
    Button check = new Button("CHECK");
    Button restart = new Button("RESET");
    Rectangle scale1 = null;
    double rotation = 0.0;
    private double currCor;
    HBox droppedBpx,floorBox,ceilBox ,initBox;
    ImageView graphic,roundGraphic;
    Label label,roundlabel;
    Integer[] numbers = new Integer[11];
    int seq =0;
    int pos = 0;
    GridPane gridPane;
    ArrayList<Text> textArray;
    ArrayList<HBox> boxArray;
    static String screen = "learning";
    TextField number ;
   // Image golfBall = new Image();
	@Override
	public void start(Stage primaryStage) throws URISyntaxException {
		primaryStage.setTitle("Rounding Off");

		int width = (int) Screen.getPrimary().getBounds().getWidth();
		int height = (int) Screen.getPrimary().getBounds().getHeight();
		
		for(int i = 0;i<11;i++)
		{
			numbers[i] = i;
		}

		root = new StackPane();

		String backGroundUrl = getClass().getResource("/images/4.jpg").toString();
		ImageView backgroundImage = new ImageView(new Image(backGroundUrl, 1500, 844, false, true));
		root.getChildren().add(backgroundImage);

	 
	
		gridPane = getLearningGridPane();
		root.getChildren().add(gridPane);
		initX = gridPane.getBoundsInLocal().getCenterX();
		//initX = gridPane.getBoundsInLocal().getWidth();
 	
		
		

		Scene scene = new Scene(root, width, height);
		scene.getStylesheets().add(this.getClass().getResource("/css/application.css").toExternalForm());
		primaryStage.setScene(scene);
		primaryStage.show();
	}

	public static void main(String[] args) {
		launch(args);
	}
	
	  private void setupPractice() throws URISyntaxException {
		  GridPane grid = this.gridPane;
		  root.getChildren().remove(grid);
		  gridPane = getPracticeGridPane();
		  root.getChildren().add(gridPane);
 	
	  }
	  
	  private void setupLearning() throws URISyntaxException {
		  GridPane grid = this.gridPane;
		  root.getChildren().remove(grid);
		  GridPane learningGrid = getLearningGridPane();
		  root.getChildren().add(learningGrid);
		
	}
	  
	  

	public GridPane getLearningGridPane() throws URISyntaxException {
		GridPane grid = new GridPane();
	
		int width = (int) Screen.getPrimary().getBounds().getWidth();
		int height = (int) Screen.getPrimary().getBounds().getHeight();
		int gridWidth = (int) (width * 1);
		int holeWidth = gridWidth / 15;
	
		grid.setPrefWidth(gridWidth);
		grid.setMinWidth(gridWidth);
		grid.setMaxWidth(gridWidth);
		grid.setMinHeight(500);
		grid.setMaxHeight(500);
		textArray = new ArrayList();
		boxArray = new ArrayList();
	//	grid.setStyle(
	//			"-fx-background-color: black, -fx-control-inner-background; -fx-background-insets: 0, 2; -fx-padding: 2;");
	
	
		 
		System.out.println(holeWidth);
		Rectangle scale = null;
		for (int column = 0; column < 15; column++) {
			for (int row = 0; row < 7; row++) {
				Image sandImage = null;
				// HBox vBox = new HBox();
				
				 if (row == 0) {
					 
					 if (column == 4) {
						 ToggleGroup group = new ToggleGroup(); 
						 ToggleButton learning = new ToggleButton("Learning"); 
					        ToggleButton practice = new ToggleButton("Exercise"); 
					        learning.setToggleGroup(group); 
					        practice.setToggleGroup(group); 
					  
					        learning.setUserData("Learning"); 
					        practice.setUserData("Exercice"); 
					  
					        // male button is selected at first by default 
					        learning.setSelected(true); 
					        
					        practice.setOnAction((ActionEvent e) -> {
					        	if(!screen.equals("practice"))
					        	{
						            try {
										setupPractice();
									} catch (URISyntaxException e1) {
										// TODO Auto-generated catch block
										e1.printStackTrace();
									}
						            screen ="practice";
					        	}
					        });
					        
					        grid.add(learning, column, row);
					        grid.add(practice, column+1, row);
						}
				        

				        
						if (column == 6) {
							scale = new Rectangle(40, 30, holeWidth, holeWidth/2);
							scale.setFill(Color.TRANSPARENT);
							grid.add(scale, column, row);
						}
							
					}
				 else if (row==1)
					{
						// if (column == 8) {
							scale = new Rectangle(0, 0, holeWidth, holeWidth);
							scale.setFill(Color.TRANSPARENT);
							grid.add(scale, column, row);
							 
						//}
					}
					
				 else if (row == 2) {
					 if (column == 0 || column == 14)
						{
						continue;	
						}
					
					 else if (column == 1)
					{
 						sandImage = new Image(getClass().getResource("/images/back.png").toURI().toString());
 			
						ImageView forwardImage = new ImageView(sandImage);

				       /* FadeTransition ft = new FadeTransition(Duration.millis(700), forwardImage);
				        ft.setFromValue(1.0);
				        ft.setToValue(0.0);
				        ft.setAutoReverse(true);
				        ft.setCycleCount(Animation.INDEFINITE);
				        ft.playFromStart();*/
						
						forwardImage.addEventHandler(MouseEvent.MOUSE_CLICKED, new EventHandler<MouseEvent>() {

						     @Override
						     public void handle(MouseEvent event) {
						          previousSeries();
						     }
						});
						     
				        grid.add(forwardImage, column, row); 

				        
				        Label prevlabel = new Label("Previous series");
				        FadeTransition fadeTransition = new FadeTransition(Duration.seconds(1), prevlabel);
				        prevlabel.setTextFill(Color.WHITE);
				        prevlabel.setFont(Font.font ("Verdana", 18));
				        prevlabel.setTextAlignment(TextAlignment.CENTER);
						
				       /* fadeTransition.setFromValue(1.0);
				        fadeTransition.setToValue(0.0);
				        fadeTransition.setCycleCount(Animation.INDEFINITE);
				        fadeTransition.play();*/
				        grid.add(prevlabel, column, row,column+1,row); 
	
					}
					else if (column == 13) 
					{
					//	scale = new Rectangle(0, 0, holeWidth, holeWidth/2);
						sandImage = new Image(getClass().getResource("/images/forward.png").toURI().toString());
						
						ImageView forwardImage = new ImageView(sandImage);

					      /*  FadeTransition ft = new FadeTransition(Duration.millis(700), forwardImage);
					        ft.setFromValue(1.0);
					        ft.setToValue(0.0);
					        ft.setAutoReverse(true);
					        ft.setCycleCount(Animation.INDEFINITE);
					        ft.playFromStart();*/
						forwardImage.addEventHandler(MouseEvent.MOUSE_CLICKED, new EventHandler<MouseEvent>() {

						     @Override
						     public void handle(MouseEvent event) {
						          nextSeries();
						     }
						});
						
					        grid.add(forwardImage, column, row); 
         
					        Label frwlabel = new Label("Next series");
					        FadeTransition fadeTransition = new FadeTransition(Duration.seconds(1), frwlabel);
					        frwlabel.setTextFill(Color.WHITE);
					        frwlabel.setFont(Font.font ("Verdana", 18));
					        frwlabel.setTextAlignment(TextAlignment.JUSTIFY);
							
					       /* fadeTransition.setFromValue(1.0);
					        fadeTransition.setToValue(0.0);
					        fadeTransition.setCycleCount(Animation.INDEFINITE);
					        fadeTransition.play();*/
					        grid.add(frwlabel, column, row,column+1,row); 
					        
	
					} else 
					{
						scale = new Rectangle(0, 0, holeWidth, holeWidth*3/2);
						sandImage = new Image(getClass().getResource("/images/flag.png").toURI().toString());
						ImagePattern sandPattern = new ImagePattern(sandImage);
						scale.setFill(sandPattern);
						grid.add(scale, column, row);
					}
					
				} else if (row==3) {
					 HBox hBox1 = new HBox();
				        hBox1.setPrefWidth(holeWidth);
				        hBox1.setPrefHeight(holeWidth*2/3);
				        hBox1.setStyle(
				        		"-fx-border-color: red;" + 
				               "-fx-border-width: 0;"
				              + "-fx-border-style: solid;");
				 
					scale = new Rectangle(0, 0, holeWidth, holeWidth*2/3);
					sandImage = new Image(getClass().getResource("/images/hole.png").toURI().toString());
					
					if (column == 1) {
						int ballSize =  holeWidth*2/3;
						//sandImage = new Image(getClass().getResource("/images/hole.png").toURI().toString());
						ImageView iv = new ImageView(new Image(getClass().getResource("/images/golfball2.png").toURI().toString(), holeWidth, ballSize, false, true));
				        
						iv.setOnMousePressed(new EventHandler<MouseEvent>() {
			                @Override
			                public void handle(MouseEvent e) {
			                	  graphic.setVisible(false);
			                	  graphic.setManaged(false);
			                	  label.setVisible(false);
			                	  label.setManaged(false);
			                }
			            });
 						
						insertImage(iv, hBox1);
				     //   vBox.getChildren().add(hBox1);
				        setupGestureTarget(hBox1);
				        initBox = hBox1;
				        grid.add(hBox1, column, row);
				       System.out.println( hBox1.getBoundsInLocal());
				       System.out.println( hBox1.getBoundsInLocal());
				       System.out.println( grid.getBoundsInLocal());
				      
				       Point2D p = new Point2D(hBox1.getBoundsInLocal().getMinX(), hBox1.getBoundsInLocal().getMinY());
				       System.out.println("p.x" + p.getX());
				         p = new Point2D(hBox1.getBoundsInLocal().getMinX(), hBox1.getBoundsInLocal().getMinY());
				       System.out.println("p.x" + p.getX());
				         p = new Point2D(iv.getBoundsInLocal().getMinX(), iv.getBoundsInLocal().getMinY());
				       System.out.println("p.x" + p.getX());
				       
					}
		
					else if (column != 0 && column <= 12) 
					{
						sandImage = new Image(getClass().getResource("/images/hole.png").toURI().toString());
	
						  HBox hBox2 = new HBox();
						  boxArray.add(hBox2);
					        hBox2.setPrefWidth(holeWidth);
					        hBox2.setPrefHeight(holeWidth*2/3);
					       // hBox2.setBackground(new Background());
					    /*    hBox2.setStyle(
					        		"-fx-border-color: blue;"+ 
					        				"-fx-border-width: 0;"
					              + "fx-background-image: url(/images/forward.png);"
					              + "-fx-border-style: solid;"); */
					      if(column ==2)
					      {
					    	  floorBox = hBox2;
					      }
					      else if(column ==12)
					      {
					    	  ceilBox = hBox2;
					      }
					      
					//	 vBox.getChildren().add(hBox2);
					     setupGestureTarget(hBox2); 
					     
					     ImagePattern sandPattern = new ImagePattern(sandImage);
							scale.setFill(sandPattern);
						//	grid.add(scale, column, row);
							grid.add(hBox2, column, row);
							Text text1 = new Text() ;
							text1.setText("" + (numbers[column-2]));
							text1.setFont(Font.font ("Verdana", 20));
							text1.setTextAlignment(TextAlignment.RIGHT);
							text1.setFill(Color.WHITE);			
							textArray.add(text1);
							grid.add(text1, column, row);
					     
					}
					
					//grid.add(scale, column, row);
				}
				 else if (row==4)
					{
					 if(column ==1)
						{
								 
						   graphic = new ImageView(new Image(getClass().getResource("/images/hand.png").toURI().toString()));

					        FadeTransition ft = new FadeTransition(Duration.millis(700), graphic);
					        ft.setFromValue(1.0);
					        ft.setToValue(0.0);
					        ft.setAutoReverse(true);
					        ft.setCycleCount(Animation.INDEFINITE);
					        ft.playFromStart();
					        grid.add(graphic, column, row); 

					        
					         label = new Label("Drag the ball on number line");
					        FadeTransition fadeTransition = new FadeTransition(Duration.seconds(1), label);
					        label.setTextFill(Color.WHITE);
					        label.setFont(Font.font ("Verdana", 16));
					        label.setTextAlignment(TextAlignment.CENTER);
 							
					        fadeTransition.setFromValue(1.0);
					        fadeTransition.setToValue(0.0);
					        fadeTransition.setCycleCount(Animation.INDEFINITE);
					        fadeTransition.play();
					        grid.add(label, column, row,column+2,row); 
					        
						}
					 
						 if (column == 8) {
							scale = new Rectangle(40, 30, holeWidth, holeWidth);
							scale.setFill(Color.TRANSPARENT);
							grid.add(scale, column, row);
							 
						}
					}
				else if (row==5)
				{
					 if(column ==5)
						{
						   roundGraphic = new ImageView(new Image(getClass().getResource("/images/roundoff.png").toURI().toString()));

					        FadeTransition ft = new FadeTransition(Duration.millis(700), roundGraphic);
					        ft.setFromValue(1.0);
					        ft.setToValue(0.0);
					        ft.setAutoReverse(true);
					        ft.setCycleCount(Animation.INDEFINITE);
					        ft.playFromStart();
					        grid.add(roundGraphic, column, row); 

					        
					        roundlabel = new Label("Click here to round off");
					        FadeTransition fadeTransition = new FadeTransition(Duration.seconds(1), roundlabel);
					        roundlabel.setTextFill(Color.WHITE);
					        roundlabel.setFont(Font.font ("Verdana", 16));
					        roundlabel.setTextAlignment(TextAlignment.CENTER);
							
					        fadeTransition.setFromValue(1.0);
					        fadeTransition.setToValue(0.0);
					        fadeTransition.setCycleCount(Animation.INDEFINITE);
					        fadeTransition.play();
					        grid.add(roundlabel, column -1, row,column,row); 
					        roundlabel.setVisible(false);
					        roundlabel.setManaged(false);
					        roundGraphic.setVisible(false);
	 						roundGraphic.setManaged(false);
					        
						}
				 
					 else if (column == 6) { 
					/*	RotateTransition rotation = new RotateTransition(Duration.seconds(0.5), roundOff);
 						rotation.setCycleCount(Animation.INDEFINITE);
 						rotation.setByAngle(30);
 						roundOff.setOnMouseEntered(e -> rotation.play());
 						roundOff.setOnMouseExited(e -> rotation.pause()); */
 						
 						roundOff.setVisible(false);
 						roundOff.setManaged(false);
						 scale1 = new Rectangle(0, 0, 90, 90);
							scale1.setFill(Color.TRANSPARENT);
							grid.add(scale1, column, row);
							
 						grid.add(roundOff, column,row);
 						roundOff.setOnAction(new EventHandler<ActionEvent>() {
 					            @Override
 					            public void handle(ActionEvent event) {
 					                roundOff();
 					            }
 					        });
 						
					}
					
					else if (column == 8) {
						String img = getClass().getResource("/images/golfball4.png").toString();
						 restart.setStyle("  -fx-background-image: url("+img+");");
						 restart.setVisible(false);
						 restart.setManaged(false);
						grid.add(restart, column, row);
						
						restart.setOnAction(new EventHandler<ActionEvent>() {
					            @Override
					            public void handle(ActionEvent event) {
					                restart();
					            }
					        });
						
						
					}
				}
				 else if (row==6)
					{
						 scale = new Rectangle(40, 30, holeWidth, holeWidth/2);
							scale.setFill(Color.TRANSPARENT);
							grid.add(scale, column, row);
						 
					}
				}
		}
	
		return grid;
	}
	
	
private GridPane getPracticeGridPane() throws URISyntaxException {

	GridPane grid = new GridPane();
	grid.setStyle(
     		"-fx-border-color: red;" + 
            "-fx-border-width: 0;"
           + "-fx-border-style: solid;");

	int width = (int) Screen.getPrimary().getBounds().getWidth();
	int height = (int) Screen.getPrimary().getBounds().getHeight();
	int gridWidth = (int) (width * 1);
	int holeWidth = gridWidth / 15;
	textArray = new ArrayList();
	boxArray = new ArrayList();

	grid.setPrefWidth(gridWidth);
	grid.setMinWidth(gridWidth);
	grid.setMaxWidth(gridWidth);
	grid.setMinHeight(500);
	grid.setMaxHeight(500);

	System.out.println(holeWidth);
	Rectangle scale = null;
	for (int column = 0; column < 15; column++) {
		for (int row = 0; row < 7; row++) {
			Image sandImage = null;
			 HBox vBox = new HBox();
			 if (row == 0) {
				 
				 if (column == 4) {
					 ToggleGroup group = new ToggleGroup(); 
					 ToggleButton learning = new ToggleButton("Learning"); 
				        ToggleButton practice = new ToggleButton("Exercise"); 
				        learning.setToggleGroup(group); 
				        practice.setToggleGroup(group); 
				  
				        learning.setUserData("Learning"); 
				        practice.setUserData("Exercice"); 
				  
				        // male button is selected at first by default 
				        practice.setSelected(true); 
				        
				        practice.setOnAction((ActionEvent e) -> {
				        	if(!screen.equals("practice"))
				        	{
					            try {
									setupPractice();
								} catch (URISyntaxException e1) {
									// TODO Auto-generated catch block
									e1.printStackTrace();
								}

				        	}
				        });
				        
				        grid.add(learning, column, row);
				        grid.add(practice, column+1, row);
					}
			        

			        
					if (column == 6) {
						scale = new Rectangle(40, 30, holeWidth, holeWidth/2);
						scale.setFill(Color.TRANSPARENT);
						grid.add(scale, column, row);
					}
						
				}
			 else if (row==1)
				{
					// if (column == 8) {
						scale = new Rectangle(0, 0, holeWidth, holeWidth);
						scale.setFill(Color.TRANSPARENT);
						grid.add(scale, column, row);
						 
					//}
				}
				
			 else if (row == 2) {
				 if (column == 0 || column == 14)
					{
					continue;	
					}
				
				 else if (column == 1)
				{
						sandImage = new Image(getClass().getResource("/images/back.png").toURI().toString());
			
					ImageView forwardImage = new ImageView(sandImage);

			       /* FadeTransition ft = new FadeTransition(Duration.millis(700), forwardImage);
			        ft.setFromValue(1.0);
			        ft.setToValue(0.0);
			        ft.setAutoReverse(true);
			        ft.setCycleCount(Animation.INDEFINITE);
			        ft.playFromStart();*/
					
					forwardImage.addEventHandler(MouseEvent.MOUSE_CLICKED, new EventHandler<MouseEvent>() {

					     @Override
					     public void handle(MouseEvent event) {
					          previousSeries();
					     }
					});
					     
			        grid.add(forwardImage, column, row); 

			        
			        Label prevlabel = new Label("Previous series");
			        FadeTransition fadeTransition = new FadeTransition(Duration.seconds(1), prevlabel);
			        prevlabel.setTextFill(Color.WHITE);
			        prevlabel.setFont(Font.font ("Verdana", 18));
			        prevlabel.setTextAlignment(TextAlignment.CENTER);
					
			       /* fadeTransition.setFromValue(1.0);
			        fadeTransition.setToValue(0.0);
			        fadeTransition.setCycleCount(Animation.INDEFINITE);
			        fadeTransition.play();*/
			        grid.add(prevlabel, column, row,column+1,row); 

				}
				else if (column == 13) 
				{
				//	scale = new Rectangle(0, 0, holeWidth, holeWidth/2);
					sandImage = new Image(getClass().getResource("/images/forward.png").toURI().toString());
					
					ImageView forwardImage = new ImageView(sandImage);

				      /*  FadeTransition ft = new FadeTransition(Duration.millis(700), forwardImage);
				        ft.setFromValue(1.0);
				        ft.setToValue(0.0);
				        ft.setAutoReverse(true);
				        ft.setCycleCount(Animation.INDEFINITE);
				        ft.playFromStart();*/
					forwardImage.addEventHandler(MouseEvent.MOUSE_CLICKED, new EventHandler<MouseEvent>() {

					     @Override
					     public void handle(MouseEvent event) {
					          nextSeries();
					     }
					});
					
				        grid.add(forwardImage, column, row); 

				        
				        Label frwlabel = new Label("Next series");
				        FadeTransition fadeTransition = new FadeTransition(Duration.seconds(1), frwlabel);
				        frwlabel.setTextFill(Color.WHITE);
				        frwlabel.setFont(Font.font ("Verdana", 18));
				        frwlabel.setTextAlignment(TextAlignment.JUSTIFY);
		
				        grid.add(frwlabel, column, row,column+1,row); 
				        

				} else 
				{
					scale = new Rectangle(0, 0, holeWidth, holeWidth*3/2);
					sandImage = new Image(getClass().getResource("/images/flag.png").toURI().toString());
					ImagePattern sandPattern = new ImagePattern(sandImage);
					scale.setFill(sandPattern);
					grid.add(scale, column, row);
				}
				
			} else if (row==3) {
				 HBox hBox1 = new HBox();
			        hBox1.setPrefWidth(holeWidth);
			        hBox1.setPrefHeight(holeWidth*2/3);
			        hBox1.setStyle(
			        		"-fx-border-color: red;" + 
			               "-fx-border-width: 0;"
			              + "-fx-border-style: solid;");
			 
				scale = new Rectangle(0, 0, holeWidth, holeWidth*2/3);
				sandImage = new Image(getClass().getResource("/images/hole.png").toURI().toString());
				
				if (column == 1) {
					
					int ballSize =  holeWidth*2/3;
					//sandImage = new Image(getClass().getResource("/images/hole.png").toURI().toString());
					ImageView iv = new ImageView(new Image(getClass().getResource("/images/golfball2.png").toURI().toString(), holeWidth, ballSize, false, true));
			        
					iv.setOnMousePressed(new EventHandler<MouseEvent>() {
		                @Override
		                public void handle(MouseEvent e) {
		                	  graphic.setVisible(false);
		                	  graphic.setManaged(false);
		                	  label.setVisible(false);
		                	  label.setManaged(false);
		                }
		            });
						
					insertImage(iv, hBox1);
			        vBox.getChildren().add(hBox1);
			        setupGestureTarget(hBox1);
			        initBox = hBox1;
			        grid.add(vBox, column, row);
			        vBox.setStyle(
			         		"-fx-border-color: red;" + 
			                "-fx-border-width: 0;"
			               + "-fx-border-style: solid;");
			   
				}
	
				else if (column != 0 && column <= 12) 
				{
					sandImage = new Image(getClass().getResource("/images/hole.png").toURI().toString());

					  HBox hBox2 = new HBox();
					  boxArray.add(hBox2);
				        hBox2.setPrefWidth(holeWidth);
				        hBox2.setPrefHeight(holeWidth*2/3);
				       // hBox2.setBackground(new Background());
				        hBox2.setStyle(
				        		"-fx-border-color: blue;"+ 
				        				"-fx-border-width: 0;"
				              + "fx-background-image: url(/images/forward.png);"
				              + "-fx-border-style: solid;");
				      if(column ==2)
				      {
				    	  floorBox = hBox2;
				      }
				      else if(column ==12)
				      {
				    	  ceilBox = hBox2;
				      }
				      
					 vBox.getChildren().add(hBox2);
				     setupGestureTarget(hBox2); 
				     
				     ImagePattern sandPattern = new ImagePattern(sandImage);
						scale.setFill(sandPattern);
						grid.add(scale, column, row);
						grid.add(vBox, column, row);
						Text text1 = new Text() ;
						text1.setText("" + (numbers[column-2]));
						text1.setFont(Font.font ("Verdana", 20));
						text1.setTextAlignment(TextAlignment.CENTER);
						text1.setFill(Color.WHITE);			
						textArray.add(text1);
						grid.add(text1, column, row);
				}
				
				//grid.add(scale, column, row);
			}
			 else if (row==4)
				{
				 if(column ==1)
					{
					  number = new TextField(); 
				        grid.add(number, column, row);
				        number.setOnAction(e -> {
				            System.out.println("textFile");
				            if(number.getText() == null || number.getText().length()==0)
			            		return;
			            	else
			                 showOnLine();
				            });
				        label = new Label("Enter the number to round");
				        FadeTransition fadeTransition = new FadeTransition(Duration.seconds(1), label);
				        label.setTextFill(Color.WHITE);
				        label.setFont(Font.font ("Verdana", 16));
				        label.setTextAlignment(TextAlignment.CENTER);
							
				        fadeTransition.setFromValue(1.0);
				        fadeTransition.setToValue(0.0);
				        fadeTransition.setCycleCount(Animation.INDEFINITE);
				        fadeTransition.play();
				        grid.add(label, column, row,column+2,row); 
					 
				       
					}
				 
				}
			else if (row==5)
			{
				 if(column ==5)
					{
					   roundGraphic = new ImageView(new Image(getClass().getResource("/images/roundoff.png").toURI().toString()));

				        FadeTransition ft = new FadeTransition(Duration.millis(700), roundGraphic);
				        ft.setFromValue(1.0);
				        ft.setToValue(0.0);
				        ft.setAutoReverse(true);
				        ft.setCycleCount(Animation.INDEFINITE);
				        ft.playFromStart();
				        grid.add(roundGraphic, column, row); 

				        
				        roundlabel = new Label("Check your answer");
				        FadeTransition fadeTransition = new FadeTransition(Duration.seconds(1), roundlabel);
				        roundlabel.setTextFill(Color.WHITE);
				        roundlabel.setFont(Font.font ("Verdana", 16));
				        roundlabel.setTextAlignment(TextAlignment.CENTER);
						
				        fadeTransition.setFromValue(1.0);
				        fadeTransition.setToValue(0.0);
				        fadeTransition.setCycleCount(Animation.INDEFINITE);
				        fadeTransition.play();
				        grid.add(roundlabel, column -1, row,column+1,row); 
				        roundlabel.setVisible(false);
				        roundlabel.setManaged(false);
				        roundGraphic.setVisible(false);
 						roundGraphic.setManaged(false);
				        
					}
			 
				 else if (column == 6) { 
				/*	RotateTransition rotation = new RotateTransition(Duration.seconds(0.5), roundOff);
						rotation.setCycleCount(Animation.INDEFINITE);
						rotation.setByAngle(30);
						roundOff.setOnMouseEntered(e -> rotation.play());
						roundOff.setOnMouseExited(e -> rotation.pause()); */
						
						check.setVisible(false);
						check.setManaged(false);
					 scale1 = new Rectangle(0, 0, 90, 90);
						scale1.setFill(Color.TRANSPARENT);
						grid.add(scale1, column, row);
						
						check.setStyle(
				        		"-fx-border-color: blue;"+ 
				        				"-fx-border-width: 0;"
				              + "fx-background-image: url(/images/forward.png);"
				              + "-fx-border-style: solid;");
						
						grid.add(check, column,row);
						check.setOnAction(new EventHandler<ActionEvent>() {
					            @Override
					            public void handle(ActionEvent event) {
					                check();
					            }

					        });
						
				}
				
				else if (column == 8) {
					String img = getClass().getResource("/images/golfball4.png").toString();
					 restart.setStyle("  -fx-background-image: url("+img+");");
					 restart.setVisible(false);
					 restart.setManaged(false);
					grid.add(restart, column, row);
					
					restart.setOnAction(new EventHandler<ActionEvent>() {
				            @Override
				            public void handle(ActionEvent event) {
				                restart();
				            }
				        });
					
					
				}
			}
			 else if (row==6)
				{
					 scale = new Rectangle(40, 30, holeWidth, holeWidth/2);
						scale.setFill(Color.TRANSPARENT);
						grid.add(scale, column, row);
					 
				}
			}
	}

	return grid;

}

private void showOnLine() {

	
	int num = Integer.parseInt(number.getText());
	seq = (num/10);
	fetchSeries(num);
	restart.setVisible(true);
	restart.setManaged(true);
	label.setVisible(false);
   	label.setManaged(false);
	
}

private void check() {
	
	if(currCor == initX)
		return;
	double diff = currCor - initX;
	int place = (int) (diff/holeWidth) -1; 
	int round = 0;
	if (pos >=5)
		round = 10;
	if(round == place)
	{
		System.out.println("true ");
		String img = getClass().getResource("/images/golfballgreen.png").toString();
		 check.setStyle("  -fx-background-image: url("+img+");");
		 check.setText("Correct");
	}
	else
	{
		System.out.println(" false");
		String img = getClass().getResource("/images/golfballred.png").toString();
		 check.setStyle("  -fx-background-image: url("+img+");");
		 check.setText("Wrong");

	}
			
}


	protected void roundOff() {
			double diff = currCor - initX;
        	int place = (int) (diff/holeWidth) -1;
        	System.out.println("Position = " + place);
        	if(place>=0)
        	{
        		currCor =initX + holeWidth;
        		ImageView img = (ImageView) droppedBpx.getChildren().get(0);
            	droppedBpx.getChildren().remove(0);
            	if(place >=5)
            	{
            		ceilBox.getChildren().add(img);
            		droppedBpx = ceilBox;
            	}
            	else   
            	{
            		floorBox.getChildren().add(img);
            		droppedBpx = floorBox;
            	}
            	String musicFile = "StayTheNight.mp3";     // For example

            /*	Media sound = new Media(new File(musicFile).toURI().toString());
            	MediaPlayer mediaPlayer = new MediaPlayer(sound);
            	mediaPlayer.play();*/
            	
        	}
        
        	 roundlabel.setVisible(false);
		     roundlabel.setManaged(false);
		     roundGraphic.setVisible(false);
			 roundGraphic.setManaged(false);
        	 roundOff.setVisible(false);
			 roundOff.setManaged(false);
        	
	        
	}
	  
	  protected void restart() {
		 	
        	ImageView img = (ImageView) droppedBpx.getChildren().get(0);
        	droppedBpx.getChildren().remove(0);
        	 
        	initBox.getChildren().add(img);
        	droppedBpx = initBox;
        	currCor = initX;
        	graphic.setVisible(true);
           	graphic.setManaged(true);
           	label.setVisible(true);
           	label.setManaged(true);
           	  
            roundOff.setVisible(false);
			roundOff.setManaged(false);
				
			roundlabel.setVisible(false);
	    	roundlabel.setManaged(false);
	    	        
	    	roundGraphic.setVisible(false);
			roundGraphic.setManaged(false);
	
			restart.setVisible(false);
			restart.setManaged(false);
			
			 String checkImg = getClass().getResource("/images/golfball3.png").toString();
			 check.setStyle("  -fx-background-image: url("+checkImg+");");
			 check.setText("Check");
			 check.setVisible(false);
			 check.setManaged(false);
			 if(number.getText()!=null)
			 {
				 number.setText(null);
			 }
			  
	       
	}
	  
	  protected void restartPractice() {
		 	
      	ImageView img = (ImageView) droppedBpx.getChildren().get(0);
      	droppedBpx.getChildren().remove(0);
      	 
      	initBox.getChildren().add(img);
      	droppedBpx = initBox;
      	currCor = initX;
      	graphic.setVisible(true);
         	graphic.setManaged(true);
         	label.setVisible(true);
         	label.setManaged(true);
         	  
          roundOff.setVisible(false);
			roundOff.setManaged(false);
				
			roundlabel.setVisible(false);
	    	roundlabel.setManaged(false);
	    	        
	    	roundGraphic.setVisible(false);
			roundGraphic.setManaged(false);
	
			restart.setVisible(false);
			restart.setManaged(false);
			
			 String checkImg = getClass().getResource("/images/golfball3.png").toString();
			 check.setStyle("  -fx-background-image: url("+checkImg+");");
			 check.setText("Check");
			 check.setVisible(false);
			 check.setManaged(false);
	       
	}
	  
	  protected void fetchSeries(int num2)
	  {
		  pos = 0;
		  for(int i=0;i<11;i++)
		    {
		    	Text text1 = textArray.remove(0);
		    	Text text2 = new Text();
		    	int num = 10*seq + numbers[i];
		    	if(num==num2)
		    		pos = i;
		    	String text = ""+ num;
		    	text2.setText(text);
		    	text2.setFont(Font.font ("Verdana", 20));
		    	text2.setTextAlignment(TextAlignment.CENTER);
		    	text2.setFill(Color.WHITE);			
				gridPane.getChildren().remove(text1);
				gridPane.add(text2,2+i,3);
				textArray.add(text2);
				
		    } 
		  ImageView img ;
		     if(initBox.getChildren().size()>0)
		     {
		    	 img = (ImageView) initBox.getChildren().remove(0);
		     }
		     else
		     {
		    	 img = (ImageView) droppedBpx.getChildren().remove(0);
		     }	 
     		
			 boxArray.get(pos).getChildren().add(img);
			 droppedBpx = boxArray.get(pos);
			 //show dialog to drag ball 
			 
			 
	  }

	  protected void nextSeries() {
		    seq ++;
		    for(int i=0;i<11;i++)
		    {
		    	Text text1 = textArray.remove(0);
		    	Text text2 = new Text();
		    	int num = 10*seq + numbers[i];
		    	String text = ""+ num;
		    	text2.setText(text);
		    	text2.setFont(Font.font ("Verdana", 20));
		    	text2.setTextAlignment(TextAlignment.CENTER);
		    	text2.setFill(Color.WHITE);			
				gridPane.getChildren().remove(text1);
				gridPane.add(text2,2+i,3);
				textArray.add(text2);
		    }
		    
	}
	  
	  protected void previousSeries() {
		    if(seq ==0)
		    	return;
		    seq --;
		    for(int i=0;i<11;i++)
		    {
		    	Text text1 = textArray.remove(0);
		    	Text text2 = new Text();
		    	int num = 10*seq + numbers[i];
		    	String text = ""+ num;
		    	text2.setText(text);
		    	text2.setFont(Font.font ("Verdana", 20));
		    	text2.setTextAlignment(TextAlignment.CENTER);
		    	text2.setFill(Color.WHITE);			
				gridPane.getChildren().remove(text1);
				gridPane.add(text2,2+i,3);
				textArray.add(text2);
		    }
			
	        
	}

	  
	void insertImage(ImageView iv, HBox hb1){
	         
	   
	        setupGestureSource(iv);

	        hb1.getChildren().add(iv);
	    }
	  
	   void setupGestureSource(final ImageView source){
	         
	        source.setOnDragDetected(new EventHandler <MouseEvent>() {

	           @Override
	           public void handle(MouseEvent event) {

	               /* allow any transfer mode */
	               Dragboard db = source.startDragAndDrop(TransferMode.MOVE);
	                
	               /* put a image on dragboard */
	               ClipboardContent content = new ClipboardContent();
	                
	               Image sourceImage = source.getImage();
	               content.putImage(sourceImage);
	               db.setContent(content);


	                iv = source ;
	               
	                
	               event.consume();
	           }
	       });
	        
	            source.setOnMouseEntered(new EventHandler<MouseEvent>() {
	                @Override
	                public void handle(MouseEvent e) {
	                    source.setCursor(Cursor.HAND);
	                    //System.out.println("e...: "+e.getSceneX());
	                    curseur = (int) e.getSceneX();
	                }
	            });
	    }
	   
	   void setupGestureTarget(final HBox targetBox){
	         
	        targetBox.setOnDragOver(new EventHandler <DragEvent>() {
	            @Override
	            public void handle(DragEvent event) {
	 
	                Dragboard db = event.getDragboard();
	                 
	                if(db.hasImage()){
	                    event.acceptTransferModes(TransferMode.MOVE);
	                }
	                 
	                event.consume();
	            }
	        });
	 
	        targetBox.setOnDragDropped(new EventHandler <DragEvent>(){

				@Override
	            public void handle(DragEvent event) {
	  
	                Dragboard db = event.getDragboard();
	 
	                if(db.hasImage()){
	                    iv.setImage(db.getImage());
	                	iv.setPreserveRatio(true);
	                    System.out.println("********");
	                    Image img =  db.getImage() ; 
	                	System.out.println(img.getWidth());
	                	System.out.println(img.getHeight());
	                	System.out.println(iv.getX());
	                	System.out.println(iv.getY());
	                    System.out.println("********");
	             
	                 
	                    Point2D localPoint = targetBox.sceneToLocal(new Point2D(event.getSceneX(), event.getSceneY()));

	                    System.out.println("event.getSceneX : "+event.getSceneX());
	                    System.out.println("localPoint.getX : "+localPoint.getX());
	                    System.out.println("localPoint.getX : "+ initX);
	                    currCor = event.getSceneX();
 	                    System.out.println("********");
	 
	                   targetBox.getChildren().remove(iv);

	                    targetBox.getChildren().add(iv);
	                    System.out.println("curseur" + curseur); 
	                    if(curseur < 200 && event.getSceneX() < 200){
	                       nombreLeft = nombreLeft+0;  
	                    }else if(curseur < 200 && event.getSceneX() > 200){
	                       nombreLeft--;
	                       nombreRight++;
	                       actualiser();
	                    }else if(curseur > 200 && event.getSceneX() > 200){
	                        nombreRight = nombreRight +0; 
	                    }else if(curseur > 200 && event.getSceneX() < 200){
	                       nombreLeft++;
	                       nombreRight--;
	                       actualiser();
	                    }   
	                    event.setDropCompleted(true);
	                    droppedBpx = targetBox;
	                }else{
	                    event.setDropCompleted(false);
	                }
	                roundOff.setVisible(true);
	    	        roundOff.setManaged(true);
	    	        
	    	        restart.setVisible(true);
	    	        restart.setManaged(true);
	    	        
	    	        roundlabel.setVisible(true);
	    	        roundlabel.setManaged(true);
	    	        
	    	        roundGraphic.setVisible(true);
	    	        roundGraphic.setManaged(true);
	    	        
	    	        check.setVisible(true);
					check.setManaged(true);
					
	                event.consume();
	            }
	        });
	         
	    }
	    
	    public void actualiser(){
	       
	    }
	    
	    void getLocation(Node n)
	    {
 	    	Point2D p = new Point2D(n.getBoundsInLocal().getMinX(), n.getBoundsInLocal().getMinY());
	    	while (n != root) {
	    	     p = n.localToParent(p);
	    	     System.out.println("p" + p);
	    	     System.out.println("p.x" + p.getX());
	    	     n = n.getParent();
	    	}

	    	 
	    }
}
