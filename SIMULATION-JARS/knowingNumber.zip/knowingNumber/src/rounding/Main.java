package rounding;

import application.Rounding;

public class Main {
	
	
	public static void main(String[] args) {
		Rounding.main(args);
	}

}
